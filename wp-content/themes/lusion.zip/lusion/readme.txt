=== lusion ===
Contributors: ArrowTheme
Requires at least: WordPress 4.5
Tested up to: WordPress 4.8.3
Version: 1.0
License:
License URI:
Tags: one-column, two-columns, right-sidebar, rtl-language-support, custom-background, custom-header, custom-menu, editor-style, featured-images, flexible-header, full-width-template, microformats, post-formats, sticky-post, theme-options, translation-ready

== Changelog ==

Initial release
